Photo to AI Restyler system:
Setup instructions:
1. Run Setup.bat and verify all file paths
2. run main.exe
3. Navigate to either the editor to change/update and add new styles or the restyler to use the service


Creating new styles:
1. Open Art Form Editor
2. Click add new art form.
3. Add the artform name (This will be used in the dropdown menu)
4. Add the artform Description (This will be used as a prompt for the ai and can be changed when running the art form restyler)

Using the Photo Restyler:
1. Click checkbox on or off for image description (Currently in beta, keep off for streamlined generation)
2. Click select image and upload an image to use for restyling.
3. select artform from the dropdown.
4. Modify prompt (If you want) to change how the photo is restyled
5. Click Restyle photo.
6. Output will be shown below as well as within the file where the exe is. Take the photo from the file and use as you please.